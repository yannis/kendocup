# class Kendocup::SessionsController < Devise::SessionsController
#   # def new
#   #   super
#   # end

#   # def create
#   #   super
#   # end
# end
