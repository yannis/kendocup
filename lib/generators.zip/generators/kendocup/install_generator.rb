module Kendocup
  class InstallGenerator < Rails::Generators::Base
    source_root File.expand_path('../templates', __FILE__)

    def copy_controller_files
      # copy_file "controllers/application_controller.rb", "#{Rails.root}/app/controllers/application_controller.rb"
      copy_file "controllers/cups_controller.rb", "#{Rails.root}/app/controllers/cups_controller.rb"
      copy_file "controllers/headlines_controller.rb", "#{Rails.root}/app/controllers/headlines_controller.rb"
      copy_file "controllers/kenshis_controller.rb", "#{Rails.root}/app/controllers/kenshis_controller.rb"
      copy_file "controllers/participations_controller.rb", "#{Rails.root}/app/controllers/participations_controller.rb"
      copy_file "controllers/purchases_controller.rb", "#{Rails.root}/app/controllers/purchases_controller.rb"
      copy_file "controllers/teams_controller.rb", "#{Rails.root}/app/controllers/teams_controller.rb"
      copy_file "controllers/users_controller.rb", "#{Rails.root}/app/controllers/users_controller.rb"
      puts "hi"
    end
  end
end
